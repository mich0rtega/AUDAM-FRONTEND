import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { authService } from '../services/authService';
import { User, UserEnvironment, Role } from '../types';

interface AuthContextType {
  user: User | null;
  currentEnvironment: UserEnvironment | null;
  environments: UserEnvironment[];
  role: Role | null;
  login: (credentials: { email: string; password: string }) => Promise<UserEnvironment[]>;
  selectEnvironment: (env: UserEnvironment) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [environments, setEnvironments] = useState<UserEnvironment[]>([]);
  const [currentEnvironment, setCurrentEnvironment] = useState<UserEnvironment | null>(null);
  const [loading, setLoading] = useState(true);

  // Al recargar la página: intentamos restaurar sesión con la cookie existente
  useEffect(() => {
    const savedEnv = localStorage.getItem('currentEnvironment');

    authService.getProfile()
      .then(async (profile) => {
        // profile = { userId, email }
        setUser({ id: profile.userId, email: profile.email });

        // Cargar entornos
        const envs = await authService.getEnvironments().catch(() => []);
        setEnvironments(envs);

        // Restaurar entorno seleccionado previamente
        if (savedEnv && envs.length > 0) {
          const parsed = JSON.parse(savedEnv);
          const found = envs.find(e => e.environmentId === parsed.environmentId);
          if (found) setCurrentEnvironment(found);
        }
      })
      .catch(() => {
        setUser(null);
        setEnvironments([]);
        setCurrentEnvironment(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const login = async (credentials: { email: string; password: string }): Promise<UserEnvironment[]> => {
    // Paso 1: login (guarda CSRF)
    await authService.login(credentials);

    // Paso 2: obtener usuario
    const profile = await authService.getProfile();
    setUser({ id: profile.userId, email: profile.email });

    // Paso 3: obtener entornos
    const envs = await authService.getEnvironments();
    setEnvironments(envs);

    return envs;
  };

  const selectEnvironment = async (env: UserEnvironment) => {
    // Paso 4: seleccionar entorno en el backend
    await authService.selectEnvironment(env.environmentId);
    setCurrentEnvironment(env);
    localStorage.setItem('currentEnvironment', JSON.stringify(env));
  };

  const logout = async () => {
    try { await authService.logout(); } catch {}
    setUser(null);
    setEnvironments([]);
    setCurrentEnvironment(null);
    localStorage.removeItem('currentEnvironment');
  };

  return (
    <AuthContext.Provider value={{
      user,
      currentEnvironment,
      environments,
      role: currentEnvironment?.role || null,
      login,
      selectEnvironment,
      logout,
      loading,
      isAuthenticated: !!user && !!currentEnvironment,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
